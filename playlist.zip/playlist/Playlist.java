/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.playlist;

/**
 *
 * @author pdiaz
 */
public class Playlist {


    public static void main(String[] args) {
       musicas P1=new musicas("CORA DE HIELO","Natt Calma","2024",2);
      P1.ShowPlaylist();
    }
}